<?php


namespace App\HttpController\Admin;


use App\HttpController\Model\PhoneCodeModel;
use EasySwoole\Http\AbstractInterface\Controller;
use EasySwoole\Http\AbstractInterface\REST;
use EasySwoole\RedisPool\RedisPool;

class PhoneCode extends Controller
{

    /**
     * @return bool
     *  获取验证码
     */
    function getPhoneCode()
    {
        try {
            $client = new \EasySwoole\HttpClient\HttpClient("http://sms.106jiekou.com/utf8/sms.aspx");//实例化Htpp客户端
            $phone = $this->request()->getQueryParam("phone");
            if (!isset($phone) || empty($phone)) {
                $this->writeJson(-101, [], "非法请求");
                return false;
            }
            //随机生成字符串
            $code_id = $this->GetRandStr(30);
            //随机生成数字
            $code = $this->GetRandStrNum(4);
            $redis = RedisPool::defer("redis");
            $redis->Set($code_id . "_" . $phone, $code, 300);
            $post_data = "account=" . Account . "&password=" . Password . "&mobile=" . $phone . "&content=" . rawurlencode("您的订单编码：" . $code . "。如需帮助请联系客服。");
            $url_info = parse_url("http://sms.106jiekou.com/utf8/sms.aspx");
            $client->setHeader("Content-Type", "application/x-www-form-urlencoded");
            $client->setHeader("Host", $url_info["host"]);
            $res = $client->post($post_data);
            $res_data = $res->getBody();

            //100 发送成功
            //101 验证失败 102 手机号码格式不正确
            //103 会员级别不够
            //104 内容未审核
            //105 内容过多或无合适匹配通道
            //106 账户余额不足
            //107 Ip受限
            //108 手机号码发送太频繁，请换号或隔天再发
            //109 帐号被锁定
            //110 手机号发送频率持续过高，黑名单屏蔽数日
            //120 系统升级
            if ($res_data == 100) {
                $this->writeJson(200, ["code_id" => $code_id], "发送成功");
                return true;
            } else if ($res_data == 108) {
                $this->writeJson(-101, [], "发送太频繁");
                return false;

            }
            $this->writeJson(-101, $res_data, "fail ");
            return false;
        } catch (\Throwable $exception) {
            $this->writeJson(-1, [], $exception->getMessage());
            return false;
        }
    }


    /***
     * 提交
     */
    function checkPhoneCode()
    {
        try {
            $code = $this->request()->getQueryParam("code");
            $code_id = $this->request()->getQueryParam("code_id");
            $phone = $this->request()->getQueryParam("phone");
            if (!isset($code) || !isset($code_id) || !isset($phone)) {
                $this->writeJson(-101, [], "非法请求");
                return false;
            }
            $redis = RedisPool::defer("redis");
            $one = $redis->get($code_id . "_" . $phone);
            if ($one == $code) {
                $one = PhoneCodeModel::create()->get(['status' => 1]);
                if (!$one) {
                    $this->writeJson(-101, [], "没有库存了!");
                    return false;
                }

                if ($one['phone'] != "") {
                    $this->writeJson(-101, [], "获取失败");
                    return false;
                }
                //更新数据
                $redis->del($code_id . "_" . $phone);
                PhoneCodeModel::create()->where(['id' => $one['id']])->update(['status' => 2, 'phone' => $phone, 'updated' => time()]);
                $this->writeJson(200, ["active_code" => $one['active_code']], "OK");
                return true;

            }
            $this->writeJson(-101, [], "验证码错误");
            return false;
        } catch (\Throwable $exception) {
            $this->writeJson(-1, [], $exception->getMessage());
            return false;
        }


    }


    //导入 激活码
    function importActivationCode()
    {
        try {
            $action = $this->request()->getParsedBody("action");

            if ($action == "GET") {

                $page = $this->request()->getRequestParam('page');         // 当前页码
                $limit = $this->request()->getRequestParam('limit');        // 每页多少条数据
                $status = $this->request()->getRequestParam('status');
                $model = PhoneCodeModel::create()->limit($limit * ($page - 1), $limit)->withTotalCount()->order('created', 'ASC');
                $list = $model->all();  //1 是可以使用的cookie  2 cookies 失效
                $result = $model->lastQueryResult();
                // 总条数
                $total = $result->getTotalCount();
                $return_data = [
                    "code" => 0,
                    "msg" => '',
                    'count' => $total,
                    'data' => $list
                ];
                $this->response()->write(json_encode($return_data));


                return  false;
            }

            $data = $this->request()->getParsedBody("data");
            if (!isset($data)) {
                $this->writeJson(-101, [], "导入失败");
                return false;
            }
            $data_array = explode("@", $data);
            foreach ($data_array as $value) {
                $one = PhoneCodeModel::create()->get(['active_code' => $value]);
                if (!$one) {
                    PhoneCodeModel::create()->data(['active_code' => $value, 'created' => time()])->save();
                }
            }
            $this->writeJson(200, [], "OK");
            return false;
        } catch (\Throwable $exception) {
            $this->writeJson(-1, [], $exception->getMessage());
            return false;

        }
    }


    /**
     * @param $length
     * @return string  生成随机字符串
     */
    function GetRandStr($length)
    {
        //字符组合
        $str = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        $len = strlen($str) - 1;
        $randstr = '';
        for ($i = 0; $i < $length; $i++) {
            $num = mt_rand(0, $len);
            $randstr .= $str[$num];
        }
        return $randstr;
    }


    function GetRandStrNum($length)
    {
        //字符组合
        $str = '0123456789';
        $len = strlen($str) - 1;
        $randstr = '';
        for ($i = 0; $i < $length; $i++) {
            $num = mt_rand(0, $len);
            $randstr .= $str[$num];
        }
        return $randstr;
    }

}