<?php



namespace App\HttpController\Model;


use EasySwoole\ORM\AbstractModel;

class AdminModel extends AbstractModel
{

    protected $tableName='admin';


}