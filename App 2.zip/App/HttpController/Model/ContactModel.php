<?php


namespace App\HttpController\Model;


class ContactModel extends AdminModel
{


    protected $tableName='contact';

}