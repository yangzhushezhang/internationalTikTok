<?php
/**
 * @Author WangYi
 * @Date 2021/9/14 2:41
 * @Version 1.0
 */


namespace App\HttpController\Model;


use EasySwoole\ORM\AbstractModel;

class CwCollectModel extends AbstractModel
{
    protected $tableName = 'cw_collect';

}