<?php


namespace App\HttpController\Model;


use EasySwoole\ORM\AbstractModel;

class DyUidModel extends AbstractModel
{

    protected $tableName = 'douyin_uid';

}