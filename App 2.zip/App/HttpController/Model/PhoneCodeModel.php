<?php


namespace App\HttpController\Model;


use EasySwoole\ORM\AbstractModel;

class PhoneCodeModel extends AbstractModel
{

    protected $tableName = "phone_code";
}