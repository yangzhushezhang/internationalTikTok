<?php


namespace App\HttpController\Model;


use EasySwoole\ORM\AbstractModel;

class TelegramModel extends AbstractModel
{
    protected $tableName = 'telegram';

}