<?php


namespace App\HttpController\Model;


use EasySwoole\ORM\AbstractModel;

class VideoLinkModel extends AbstractModel
{
    protected $tableName = 'video_link';

}