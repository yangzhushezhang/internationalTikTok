<?php


namespace App\HttpController\Model;


use EasySwoole\ORM\AbstractModel;

class FansTModel extends AbstractModel
{

    protected $tableName = 'fans_t';

}