<?php


namespace App\HttpController\Model;


use EasySwoole\ORM\AbstractModel;

class MonitorFansModel extends AbstractModel
{
    protected $tableName = 'monitor_fans';

}