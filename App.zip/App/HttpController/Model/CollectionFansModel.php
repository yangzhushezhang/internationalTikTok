<?php


namespace App\HttpController\Model;


use EasySwoole\ORM\AbstractModel;

class CollectionFansModel extends AbstractModel
{

    protected $tableName = 'collection_fans';

}