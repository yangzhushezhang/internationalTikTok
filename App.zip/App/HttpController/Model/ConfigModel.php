<?php


namespace App\HttpController\Model;


class ConfigModel extends AdminModel
{

    protected $tableName='config';

}