<?php


namespace App\HttpController\Model;


use EasySwoole\ORM\AbstractModel;

class CookiesModel extends AbstractModel
{
    protected $tableName = "cookies";

}