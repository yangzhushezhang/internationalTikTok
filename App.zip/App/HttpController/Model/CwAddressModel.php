<?php


namespace App\HttpController\Model;


use EasySwoole\ORM\AbstractModel;

class CwAddressModel extends AbstractModel
{

    protected $tableName = 'cw_address';

}