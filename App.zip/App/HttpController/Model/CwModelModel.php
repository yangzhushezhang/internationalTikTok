<?php


namespace App\HttpController\Model;


use EasySwoole\ORM\AbstractModel;

class CwModelModel extends AbstractModel
{
    protected $tableName = 'cw_model';

}