<?php


namespace App\HttpController\Model;


use EasySwoole\ORM\AbstractModel;

class DyName extends AbstractModel
{

    protected $tableName='douyin_name';

}