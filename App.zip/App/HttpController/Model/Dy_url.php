<?php


namespace App\HttpController\Model;


use EasySwoole\ORM\AbstractModel;

class Dy_url extends AbstractModel
{
    protected $tableName = 'dy_url';

}