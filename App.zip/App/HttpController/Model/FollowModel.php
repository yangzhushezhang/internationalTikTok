<?php


namespace App\HttpController\Model;


use EasySwoole\ORM\AbstractModel;

class FollowModel extends AbstractModel
{
    protected $tableName='follow';

}