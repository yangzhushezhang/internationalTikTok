<?php


namespace App\HttpController\Model;


use EasySwoole\ORM\AbstractModel;

class JournalModel extends AbstractModel
{

    protected $tableName = 'journal';

}