<?php


namespace App\HttpController\Model;


use EasySwoole\ORM\AbstractModel;

class MatchingModel extends AbstractModel
{
    protected $tableName = 'matching';

}