<?php


namespace App\HttpController\Model;


use EasySwoole\ORM\AbstractModel;

class MonitorVideoModel extends AbstractModel
{
    protected $tableName = 'monitor_video';

}