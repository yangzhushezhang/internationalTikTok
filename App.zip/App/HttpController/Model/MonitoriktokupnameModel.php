<?php


namespace App\HttpController\Model;


use EasySwoole\ORM\AbstractModel;

class MonitoriktokupnameModel extends AbstractModel
{
    protected $tableName = 'monitortiktokupname';

}