<?php


namespace App\HttpController\Model;


use EasySwoole\ORM\AbstractModel;

class RecentlySoldModel extends AbstractModel
{
    protected $tableName='recently_sold';


}