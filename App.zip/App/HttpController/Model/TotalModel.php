<?php
/**
 * @Author WangYi
 * @Date 2021/6/3 18:37
 * @Version 1.0
 */


namespace App\HttpController\Model;


use EasySwoole\ORM\AbstractModel;

class TotalModel extends AbstractModel
{
    protected $tableName='total';

}