<?php
/**
 * @Author WangYi
 * @Date 2021/5/28 23:08
 * @Version 1.0
 */


namespace App\HttpController\Model;


use EasySwoole\ORM\AbstractModel;

class TwoDouyinModel extends AbstractModel
{

    protected $tableName = 'two_douyin';

}