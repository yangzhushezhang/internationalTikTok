<?php


namespace App\HttpController\Model;


use EasySwoole\ORM\AbstractModel;

class UidTModel extends AbstractModel
{

    protected $tableName = 'uid_t';

}