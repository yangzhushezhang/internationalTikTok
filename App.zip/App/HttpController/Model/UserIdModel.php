<?php


namespace App\HttpController\Model;


use EasySwoole\ORM\AbstractModel;

class UserIdModel extends AbstractModel
{
    protected $tableName="userId" ;

}