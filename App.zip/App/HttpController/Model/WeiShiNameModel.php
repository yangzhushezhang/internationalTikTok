<?php


namespace App\HttpController\Model;


use EasySwoole\ORM\AbstractModel;

class WeiShiNameModel extends AbstractModel
{
    protected $tableName = 'weishi_name';

}