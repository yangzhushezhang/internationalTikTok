<?php


namespace App\HttpController\Model;


use EasySwoole\ORM\AbstractModel;

class WhatsAppModel extends AbstractModel
{
    protected $tableName="whats_app"  ;

}